'use client'
import { useEffect, useState } from 'react';

export default function AddData() {
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        image: '',
    });

    const [data, setData] = useState(null);  // State to hold the fetched data

    useEffect(() => {
        handleGetData();
    }, []); // Empty dependency array to call once on mount

    const handleGetData = async () => {
        try {
            const response = await fetch('/api/getdata', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }

            const data = await response.json();
            setData(data);  // Store the fetched data in state
        } catch (error) {
            console.error('Error fetching data:', error);
            setResponseMessage('Failed to fetch data.');
        }
    };



    const [responseMessage, setResponseMessage] = useState('');

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/addData', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }

            const data = await response.json();
            handleGetData()
            setResponseMessage(data.message);
        } catch (error) {
            console.error('Error submitting data:', error);
            setResponseMessage('Failed to add data.');
        }
    };

    const handleDeleteData = async (id) => {
        try {
            const response = await fetch('/api/deleteData', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id }), // Pass the id of the document to delete
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }

            const result = await response.json();
            if (result) {
                handleGetData()
            }
        } catch (error) {
            console.error('Error deleting data:', error);
        }
    };


    return (
        <div>
            <h1>Add Data</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>
                        Name:
                        <input type="text" name="name" value={formData.name} onChange={handleChange} />
                    </label>
                </div>
                <div>
                    <label>
                        Description:
                        <textarea name="description" value={formData.description} onChange={handleChange}></textarea>
                    </label>
                </div>
                <div>
                    <label>
                        Image URL:
                        <input type="text" name="image" value={formData.image} onChange={handleChange} />
                    </label>
                </div>
                <button type="submit">Submit</button>
            </form>

            <div>
                <div className='container'>
                    <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th scope="col" className="px-16 py-3">
                                        <span className="sr-only">Image</span>
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Product
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Qty
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Price
                                    </th>
                                    <th scope="col" className="px-6 py-3">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                {data?.data?.map((item, index) => {
                                    return (
                                        <tr key={index} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                            <td className="p-4">
                                                <img src={item?.image} className="w-16 md:w-32 max-w-full max-h-full" alt="" />
                                            </td>
                                            <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                                                {item?.name}
                                            </td>
                                            <td className="px-6 py-4">
                                                {item?.description}
                                            </td>
                                            <td className="px-6 py-4">
                                                <a
                                                    href="#"
                                                    className="font-medium text-red-600 dark:text-red-500 hover:underline"
                                                    onClick={(e) => {
                                                        e.preventDefault(); // Prevent the default anchor tag behavior
                                                        handleDeleteData(item?._id); // Call handleDeleteData when clicked
                                                    }}
                                                >
                                                    Remove
                                                </a>

                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
